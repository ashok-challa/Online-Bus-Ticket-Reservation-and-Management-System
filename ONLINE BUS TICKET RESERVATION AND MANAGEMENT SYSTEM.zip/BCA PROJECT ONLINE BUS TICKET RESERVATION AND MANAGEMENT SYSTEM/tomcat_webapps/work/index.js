function f1()
{
 window.location="home.jsp";
}
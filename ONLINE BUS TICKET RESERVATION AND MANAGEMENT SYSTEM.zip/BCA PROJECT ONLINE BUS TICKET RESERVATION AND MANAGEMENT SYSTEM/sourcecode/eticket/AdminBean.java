/*
 * Created on Dec 2, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package eticket;

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AdminBean {
	protected String afname,alname,username,pass,aaddress1,aaddress2,acity,astate,aemail,aphno;
	
	public void setAfname(String s) {this.afname=s;}
	public void setAlname(String s) {this.alname=s;}
	public void setUsername(String s) {this.username=s;}
	public void setPass(String s) {this.pass=s;}
	public void setAaddress1(String s) {this.aaddress1=s;}
	public void setAaddress2(String s) {this.aaddress2=s;}
	public void setAcity(String s) {this.acity=s;}
	public void setAstate(String s) {this.astate=s;}
	public void setAphno(String s) {this.aphno=s;}
	public void setAemail(String s) {this.aemail=s;}
	
	public String getAfname() {return afname;}
	public String getAlname() {return alname;}
	public String getUsername() {return username;}
	public String getPass() {return pass;}
	public String getAaddress1() {return aaddress1;}
	public String getAaddress2() {return aaddress2;}
	public String getAcity() {return acity;}
	public String getAstate() {return astate;}
	public String getAemail() {return aemail;}
	public String getAphno() {return aphno;}

}
